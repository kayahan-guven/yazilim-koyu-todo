<template>
  <reminders></reminders>
</template>

<script>
    import Reminders from "./view/Reminders"

    export default {
      components: {
        Reminders
      }
    }
</script>

<style>
</style>
