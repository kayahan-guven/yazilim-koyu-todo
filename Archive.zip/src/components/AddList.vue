<template>
  <div class="add-list-block">
    <font-awesome-icon icon="plus-circle" class="icon"/>
    <div>Add List</div>
  </div>
</template>

<script>

</script>

<style scoped>
    .add-list-block {
      display: flex;
    }

    .icon {
      margin-right: 10px;
    }
</style>
